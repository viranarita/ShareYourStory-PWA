import UrlParser from '../routes/url-parser';
import routes from '../routes/routes';

import AuthHelper from '../utils/auth-helper';
import renderNav from '../utils/navigation'; 

import HomePage from '../pages/home/home-page';
import HomePagePresenter from '../presenters/home-page-presenter';
import * as ApiSource from '../data/api';

class App {
  #content = null;
  #drawerButton = null;
  #navigationDrawer = null;

  constructor({ navigationDrawer, drawerButton, content }) {
    this.#content = content;
    this.#drawerButton = drawerButton;
    this.#navigationDrawer = navigationDrawer;
    this._setupDrawer();
  }

  _setupDrawer() {
    this.#drawerButton.addEventListener('click', () => {
      this.#navigationDrawer.classList.toggle('open');
    });

    document.body.addEventListener('click', (event) => {
      if (!this.#navigationDrawer.contains(event.target) && !this.#drawerButton.contains(event.target)) {
        this.#navigationDrawer.classList.remove('open');
      }
      this.#navigationDrawer.querySelectorAll('a').forEach((link) => {
        if (link.contains(event.target)) {
          this.#navigationDrawer.classList.remove('open');
        }
      });
    });
  }

  async renderPage() {
    this._updateNavigation(); 
    this.#content.classList.add('fade-out');
    await new Promise(resolve => setTimeout(resolve, 300));
    const url = UrlParser.parseActiveUrlWithCombiner();
    const PageComponent = routes[url] || routes['/'];
    
    if (PageComponent === HomePage) {
      const view = new HomePage();
      this.#content.innerHTML = await view.render();
      new HomePagePresenter({ view, api: ApiSource });
    } else {
      const page = new PageComponent(); 
      this.#content.innerHTML = await page.render();
      if (page.afterRender) {
        await page.afterRender();
      }
    }
    this.#content.classList.remove('fade-out');
  }
  
  _updateNavigation() {
    const authToken = AuthHelper.isAuthenticated();
    const navList = document.querySelector('#nav-list'); 
    
    if (!navList) return; 

    if (authToken) {
      const userName = AuthHelper.getUserName();
      navList.innerHTML = `
        <li><a href="#/">Beranda</a></li>
        <li><a href="#/add">Tambah Cerita</a></li>
        <li><a href="#/about">About</a></li>
        <li><a id="logout-button" href="#">Logout (${userName})</a></li>
      `;
      const logoutButton = document.querySelector('#logout-button');
      if (logoutButton) {
        logoutButton.addEventListener('click', (event) => {
          event.preventDefault();
          AuthHelper.logout(); 
          alert('Anda berhasil logout.');
          window.location.hash = '#/';
          window.location.reload();
        });
      }
    } else {
      navList.innerHTML = `
        <li><a href="#/">Beranda</a></li>
        <li><a href="#/about">About</a></li>
        <li><a href="#/login">Login</a></li>
      `;
    }
  }
}

export default App;